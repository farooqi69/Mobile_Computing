package com.example.servicesms;

public class MessageLogs {

    public String PhoneNumber;
    public String body;
    public String Type;
    public String date;

    public MessageLogs() {

    }
}