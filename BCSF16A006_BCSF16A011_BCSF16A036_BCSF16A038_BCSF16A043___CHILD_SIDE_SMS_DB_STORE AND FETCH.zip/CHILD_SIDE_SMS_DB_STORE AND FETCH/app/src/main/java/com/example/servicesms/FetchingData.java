package com.example.servicesms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class FetchingData extends AppCompatActivity {

   // TextView usrtxt;
   // TextView pwdtxt;

    ListView LV;
    List list;

    Button fetchbtn;
    DatabaseReference reff;
    String header="Message Details:";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fetching_data);


        LV=findViewById(R.id.LV);
        list=new ArrayList<>();
     //   usrtxt=findViewById(R.id.usrtxt);
      //  pwdtxt=findViewById(R.id.pwdtxt);
        reff= FirebaseDatabase.getInstance().getReference().child("m");



                reff.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){

                            String PHfrmDB=String.valueOf(dataSnapshot1.child("PhoneNumber").getValue());
                            String CDfrmDB=String.valueOf(dataSnapshot1.child("Type").getValue());
                            String CTfrmDB=String.valueOf(dataSnapshot1.child("body").getValue());
                            String DatefrmDB=String.valueOf(dataSnapshot1.child("date").getValue());


                            list.add(header);
                            list.add(PHfrmDB);
                            list.add(CDfrmDB);
                            list.add(CTfrmDB);
                            list.add(DatefrmDB);

                            ArrayAdapter arrayAdapter=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,list);
                            LV.setAdapter(arrayAdapter);


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });



    }
}

/*


reff.addValueEventListener(new ValueEventListener() {
@Override
public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

        for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()) {

        // ParentInfo parentInfo = new ParentInfo();
*/
/*
                            String PHFrmDB = String.valueOf(dataSnapshot1.child("PhoneNumber").getValue());
                            String BodyFrmDB = String.valueOf(dataSnapshot1.child("body").getValue());
                            String TypeFrmDB = String.valueOf(dataSnapshot1.child("Type").getValue());
                            String DateFrmDB = String.valueOf(dataSnapshot1.child("date").getValue());*//*



        String PHfrmDB=String.valueOf(dataSnapshot1.child("PhoneNumber").getValue());

        list.add(PHfrmDB);*/
/*
                            list.add(TypeFrmDB);
                            list.add(BodyFrmDB);
                            list.add(DateFrmDB);*//*


        ArrayAdapter arrayAdapter=new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,list);
        LV.setAdapter(arrayAdapter);

        //   Toast.makeText(FetchingData.this, usrFrmDB, Toast.LENGTH_SHORT).show();
        //     Toast.makeText(FetchingData.this, pwdFrmDB, Toast.LENGTH_SHORT).show();


        //    usrtxt.setText(usrFrmDB);
        //   pwdtxt.setText(pwdFrmDB);



        }
        }

@Override
public void onCancelled(@NonNull DatabaseError databaseError) {

        }
        });*/
