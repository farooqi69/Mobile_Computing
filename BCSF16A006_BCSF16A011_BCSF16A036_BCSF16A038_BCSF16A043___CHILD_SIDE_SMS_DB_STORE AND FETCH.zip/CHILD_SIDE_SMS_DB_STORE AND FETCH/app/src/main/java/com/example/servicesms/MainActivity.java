package com.example.servicesms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button buttonStart, buttonStop, fetchData;


    private int Request_code = 1;
    public  String [] permissions={Manifest.permission.READ_SMS};
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonStart = findViewById(R.id.buttonStart);
        buttonStop = findViewById(R.id.buttonStop);
        fetchData=findViewById(R.id.fd);


        fetchData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(MainActivity.this,FetchingData.class);
                startActivity(intent);
            }
        });

        buttonStart.setOnClickListener(this);
        buttonStop.setOnClickListener(this);
        if(!hasPermissions(this,permissions))
        {
            ActivityCompat.requestPermissions(this,permissions,Request_code);
        }


    }

    public static boolean hasPermissions(Context context, String ... permissions)
    {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M  && context !=null && permissions != null)
        {
            for(String permission:permissions)
            {
                if(ActivityCompat.checkSelfPermission(context,permission) != PackageManager.PERMISSION_GRANTED)
                {
                    return false;
                }
            }
        }
        return true;
    }
    public void onClick(View src) {
        switch (src.getId()) {
            case R.id.buttonStart:

                startService(new Intent(this, MyService.class));
                break;
            case R.id.buttonStop:
                stopService(new Intent(this, MyService.class));
                break;
        }
    }



}
